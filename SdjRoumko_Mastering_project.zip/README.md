# SdjRoumko Mastering — Cloud Build

This version is deliberately independent of MobileStudio.

Build configuration:
- Gradle 9.1.0
- Android Gradle Plugin 9.0.1
- Built-in Kotlin (AGP 9)
- Android compileSdk 35
- JDK 17 on GitHub Actions
- No coroutines dependency
- No FileProvider dependency
- WAV export uses Android's Create Document picker

## Build the APK

1. Create a GitHub repository.
2. Upload this entire project to the repository.
3. GitHub Actions will run automatically on `main`.
4. Open the workflow run and download the artifact named `SdjRoumko-Mastering-debug`.

You can also start it manually from Actions → Build APK → Run workflow.
