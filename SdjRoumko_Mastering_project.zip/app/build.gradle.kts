plugins {
    id("com.android.application")
}

android {
    namespace = "com.sdjroumko.mastering"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sdjroumko.mastering"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
}
