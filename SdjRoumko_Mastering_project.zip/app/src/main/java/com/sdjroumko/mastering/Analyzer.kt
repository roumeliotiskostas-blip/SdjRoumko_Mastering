package com.sdjroumko.mastering

import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

object Analyzer {
    fun peak(d: WavData): Float = d.samples.maxOf { kotlin.math.abs(it) }.coerceAtLeast(1e-9f)
    fun rms(d: WavData): Float {
        var sum = 0.0
        for (x in d.samples) sum += x.toDouble() * x.toDouble()
        return sqrt(sum / d.samples.size).toFloat().coerceAtLeast(1e-9f)
    }
    fun db(x: Float) = 20f * log10(x.coerceAtLeast(1e-9f))
    fun report(d: WavData): String {
        val p = peak(d)
        val r = rms(d)
        return """
            SAMPLE RATE : ${d.sampleRate} Hz
            CHANNELS    : ${d.channels}
            PEAK        : ${"%.2f".format(db(p))} dBFS
            RMS         : ${"%.2f".format(db(r))} dBFS
            APPROX LUFS : ${"%.2f".format(db(r) - 0.7f)} LUFS
        """.trimIndent()
    }
}
