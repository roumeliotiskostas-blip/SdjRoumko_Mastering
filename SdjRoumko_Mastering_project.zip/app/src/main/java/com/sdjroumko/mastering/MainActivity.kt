package com.sdjroumko.mastering

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.sdjroumko.mastering.databinding.ActivityMainBinding
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var loaded: WavData? = null
    private var mastered: WavData? = null
    private var sourceName = "SdjRοumko_Master"
    private val executor = Executors.newSingleThreadExecutor()

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        binding.status.text = "Loading WAV..."
        executor.execute {
            try {
                val data = WavCodec.read(contentResolver, uri)
                runOnUiThread {
                    loaded = data
                    mastered = null
                    binding.masterButton.isEnabled = true
                    binding.previewButton.isEnabled = false
                    binding.exportButton.isEnabled = false
                    binding.status.text = "Loaded: ${data.sampleRate} Hz / ${data.channels} ch"
                    binding.analysis.text = Analyzer.report(data)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    binding.status.text = "Error"
                    Toast.makeText(this, e.message ?: "Invalid WAV", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val exporter = registerForActivityResult(
        ActivityResultContracts.CreateDocument("audio/wav")
    ) { uri: Uri? ->
        val out = mastered ?: return@registerForActivityResult
        uri ?: return@registerForActivityResult
        binding.status.text = "Exporting WAV 24-bit..."
        executor.execute {
            try {
                contentResolver.openOutputStream(uri).use { stream ->
                    requireNotNull(stream) { "Cannot open output file" }
                    WavCodec.write24(stream, out)
                }
                runOnUiThread { binding.status.text = "Export complete" }
            } catch (e: Exception) {
                runOnUiThread { binding.status.text = "Export error: ${e.message}" }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.openButton.setOnClickListener {
            picker.launch(arrayOf("audio/wav", "audio/x-wav", "audio/*"))
        }

        binding.masterButton.setOnClickListener {
            val input = loaded ?: return@setOnClickListener
            binding.status.text = "Analyzing + mastering offline..."
            binding.masterButton.isEnabled = false
            executor.execute {
                try {
                    val result = MasterEngine.master(input)
                    runOnUiThread {
                        mastered = result
                        binding.analysis.text = Analyzer.report(result)
                        binding.status.text = "Master ready — fully offline"
                        binding.masterButton.isEnabled = true
                        binding.previewButton.isEnabled = true
                        binding.exportButton.isEnabled = true
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        binding.masterButton.isEnabled = true
                        binding.status.text = "Mastering error: ${e.message}"
                    }
                }
            }
        }

        binding.previewButton.setOnClickListener {
            Toast.makeText(this, "Preview module is next. DSP engine is ready.", Toast.LENGTH_SHORT).show()
        }

        binding.exportButton.setOnClickListener {
            exporter.launch("${sourceName}_${System.currentTimeMillis()}.wav")
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
