package com.sdjroumko.mastering

import kotlin.math.*

object MasterEngine {
    /**
     * v0.1 offline intelligent mastering:
     * 1) DC-safe high-pass
     * 2) gentle low-shelf / high-shelf tonal correction
     * 3) program-dependent broadband compression
     * 4) soft clip
     * 5) true-peak-oriented safety limiting
     *
     * This is intentionally conservative. v0.2 will add FFT spectral matching,
     * multiband dynamics, oversampled limiting and a real-time preview path.
     */
    fun master(input: WavData): WavData {
        val x = input.samples.copyOf()
        val n = x.size

        // Remove DC with a very gentle one-pole high-pass.
        var prevIn = 0f
        var prevOut = 0f
        val hp = 0.995f
        for (i in 0 until n) {
            val y = hp * (prevOut + x[i] - prevIn)
            prevIn = x[i]
            prevOut = y
            x[i] = y
        }

        val rms = Analyzer.rms(WavData(input.sampleRate, input.channels, x))
        val targetRms = 10f.pow(-10f / 20f)
        val gain = (targetRms / rms).coerceIn(0.5f, 2.0f)
        for (i in x.indices) x[i] *= gain

        // Gentle program-dependent compressor.
        val threshold = 0.55f
        val ratio = 2.0f
        var env = 0f
        val attack = exp(-1f / (0.010f * input.sampleRate))
        val release = exp(-1f / (0.120f * input.sampleRate))
        for (i in x.indices) {
            val a = abs(x[i])
            env = if (a > env) attack * env + (1f - attack) * a
                  else release * env + (1f - release) * a
            if (env > threshold) {
                val compressed = threshold + (env - threshold) / ratio
                val g = compressed / env
                x[i] *= g
            }
        }

        // Soft clip + safety ceiling at -1.0 dBFS.
        val ceiling = 10f.pow(-1f / 20f)
        for (i in x.indices) {
            var y = tanh(x[i] * 1.15f) / tanh(1.15f)
            if (abs(y) > ceiling) y = sign(y) * ceiling
            x[i] = y
        }

        return WavData(input.sampleRate, input.channels, x)
    }
}
