package com.sdjroumko.mastering

import android.content.ContentResolver
import android.net.Uri
import java.io.*

data class WavData(
    val sampleRate: Int,
    val channels: Int,
    val samples: FloatArray
)

object WavCodec {
    private fun readIntLE(b: ByteArray, o: Int) =
        (b[o].toInt() and 255) or ((b[o+1].toInt() and 255) shl 8) or
        ((b[o+2].toInt() and 255) shl 16) or ((b[o+3].toInt() and 255) shl 24)

    private fun readShortLE(b: ByteArray, o: Int) =
        (b[o].toInt() and 255) or ((b[o+1].toInt() and 255) shl 8)

    fun read(resolver: ContentResolver, uri: Uri): WavData {
        resolver.openInputStream(uri).use { ins ->
            requireNotNull(ins)
            val bytes = ins.readBytes()
            require(String(bytes, 0, 4, Charsets.US_ASCII) == "RIFF") { "Not RIFF/WAV" }
            require(String(bytes, 8, 4, Charsets.US_ASCII) == "WAVE") { "Not WAVE" }

            var p = 12
            var fmt = -1
            var channels = 0
            var rate = 0
            var bits = 0
            var dataStart = -1
            var dataSize = 0

            while (p + 8 <= bytes.size) {
                val id = String(bytes, p, 4, Charsets.US_ASCII)
                val size = readIntLE(bytes, p + 4)
                val start = p + 8
                if (id == "fmt ") {
                    fmt = readShortLE(bytes, start)
                    channels = readShortLE(bytes, start + 2)
                    rate = readIntLE(bytes, start + 4)
                    bits = readShortLE(bytes, start + 14)
                } else if (id == "data") {
                    dataStart = start
                    dataSize = size
                    break
                }
                p = start + size + (size and 1)
            }

            require(fmt == 1) { "This v0.1 build accepts PCM WAV only." }
            require(channels in 1..2) { "Only mono/stereo WAV is supported." }
            require(bits == 16 || bits == 24 || bits == 32) { "Use 16/24/32-bit PCM WAV." }
            require(dataStart >= 0) { "WAV data chunk not found." }

            val end = minOf(bytes.size, dataStart + dataSize)
            val bytesPerSample = bits / 8
            val frameBytes = bytesPerSample * channels
            val frames = (end - dataStart) / frameBytes
            val out = FloatArray(frames * channels)
            var q = dataStart
            var i = 0
            repeat(frames * channels) {
                out[i++] = when (bits) {
                    16 -> readShortLE(bytes, q).toShort() / 32768f
                    24 -> {
                        val v = (bytes[q].toInt() and 255) or
                                ((bytes[q+1].toInt() and 255) shl 8) or
                                ((bytes[q+2].toInt() and 255) shl 16)
                        val s = if ((v and 0x800000) != 0) v or -0x1000000 else v
                        s / 8388608f
                    }
                    else -> readIntLE(bytes, q) / 2147483648f
                }
                q += bytesPerSample
            }
            return WavData(rate, channels, out)
        }
    }

    fun write24(file: File, d: WavData) {
        FileOutputStream(file).use { write24(it, d) }
    }

    fun write24(stream: OutputStream, d: WavData) {
        val bytesPerSample = 3
        val dataSize = d.samples.size * bytesPerSample
        DataOutputStream(BufferedOutputStream(stream)).use { out ->
            fun le16(v: Int) { out.write(v and 255); out.write((v ushr 8) and 255) }
            fun le32(v: Int) {
                out.write(v and 255); out.write((v ushr 8) and 255)
                out.write((v ushr 16) and 255); out.write((v ushr 24) and 255)
            }
            out.writeBytes("RIFF"); le32(36 + dataSize); out.writeBytes("WAVE")
            out.writeBytes("fmt "); le32(16); le16(1); le16(d.channels)
            le32(d.sampleRate); le32(d.sampleRate * d.channels * 3)
            le16(d.channels * 3); le16(24)
            out.writeBytes("data"); le32(dataSize)
            for (x0 in d.samples) {
                val x = x0.coerceIn(-1f, 0.999999f)
                val v = (x * 8388607f).toInt()
                out.write(v and 255); out.write((v ushr 8) and 255); out.write((v ushr 16) and 255)
            }
        }
    }
}
