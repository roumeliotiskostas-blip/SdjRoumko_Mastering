# SdjRοumko Mastering v0.3.0

Offline Android mastering application.

## v0.3.0
- 24-band parametric bell EQ, 20 Hz–20 kHz.
- Per-band gain and Q controls.
- Program-dependent 4-band dynamics.
- Loudness targeting with conservative automatic gain.
- Stereo width control and low-frequency mono compatibility control.
- Harmonic saturation.
- Look-ahead style peak control plus 4x interpolated true-peak safety pass.
- 24-bit triangular dither before export.
- Approximate K-weighted LUFS, RMS, sample peak, true-peak estimate and crest factor metering.
- Real A/B audio preview through Android AudioTrack.
- WAV input: PCM 16/24/32-bit integer and 32-bit float, mono/stereo.
- WAV output: 24-bit PCM.

## Build
- Gradle 9.1.0
- Android Gradle Plugin 9.0.1
- compileSdk 35 / targetSdk 35
- JDK 17 on GitHub Actions

The app is designed so the DSP chain can later be extended with native C++ DSP, certified EBU R128 metering, multichannel/surround processing and separately licensed delivery codecs such as DTS. DTS encoding is not included in v0.3.0.
