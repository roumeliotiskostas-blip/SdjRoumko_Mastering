package com.sdjroumko.mastering

import kotlin.math.*

object Analyzer {
    fun peak(d: WavData): Float = d.samples.maxOfOrNull { abs(it) }?.coerceAtLeast(1e-9f) ?: 1e-9f
    fun rms(d: WavData): Float {
        if (d.samples.isEmpty()) return 1e-9f
        var sum = 0.0
        for (x in d.samples) sum += x.toDouble() * x.toDouble()
        return sqrt(sum / d.samples.size).toFloat().coerceAtLeast(1e-9f)
    }
    fun db(x: Float) = 20f * log10(x.coerceAtLeast(1e-9f))
    fun lufsApprox(d: WavData): Float {
        if (d.samples.isEmpty()) return -99f
        // Lightweight K-weighted integrated estimate. The mastering engine also
        // reports RMS for diagnostics; this is intentionally not a certification meter.
        val x = d.samples.copyOf()
        var hpX = 0f; var hpY = 0f; var shelf = 0f
        val hpA = exp(-2.0 * Math.PI * 60.0 / d.sampleRate).toFloat()
        val shelfA = exp(-2.0 * Math.PI * 1500.0 / d.sampleRate).toFloat()
        var sum = 0.0
        for (v in x) {
            hpY = hpA * (hpY + v - hpX); hpX = v
            shelf = shelfA * shelf + (1f - shelfA) * hpY
            val k = hpY + 0.12f * shelf
            sum += k.toDouble() * k.toDouble()
        }
        val mean = (sum / x.size).coerceAtLeast(1e-12)
        return (10.0 * log10(mean) - 0.691).toFloat()
    }
    fun truePeakApprox(d: WavData): Float {
        if (d.samples.isEmpty()) return 0f
        var peak = 0f
        val c = d.channels.coerceAtLeast(1)
        if (c == 1) {
            for (i in 0 until d.samples.lastIndex) {
                val a = d.samples[i]; val b = d.samples[i + 1]
                peak = max(peak, abs(a)); peak = max(peak, abs((3f*a+b)/4f)); peak = max(peak, abs((a+3f*b)/4f)); peak = max(peak, abs(b))
            }
        } else {
            var i = 0
            while (i + c < d.samples.size) {
                for (ch in 0 until c) {
                    val a = d.samples[i + ch]; val b = d.samples[i + c + ch]
                    peak = max(peak, abs(a)); peak = max(peak, abs((3f*a+b)/4f)); peak = max(peak, abs((a+3f*b)/4f)); peak = max(peak, abs(b))
                }
                i += c
            }
        }
        return peak.coerceAtLeast(1e-9f)
    }
    fun crestFactorDb(d: WavData): Float = db(peak(d)) - db(rms(d))
    fun report(d: WavData): String {
        val p = peak(d); val tp = truePeakApprox(d); val r = rms(d)
        return """
            SAMPLE RATE : ${d.sampleRate} Hz
            CHANNELS    : ${d.channels}
            SAMPLE PEAK : ${"%.2f".format(db(p))} dBFS
            TRUE PEAK~  : ${"%.2f".format(db(tp))} dBTP
            RMS         : ${"%.2f".format(db(r))} dBFS
            LUFS~       : ${"%.2f".format(lufsApprox(d))} LUFS
            CREST       : ${"%.2f".format(crestFactorDb(d))} dB
        """.trimIndent()
    }
}
