package com.sdjroumko.mastering

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.sdjroumko.mastering.databinding.ActivityMainBinding
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var loaded: WavData? = null
    private var mastered: WavData? = null
    private var sourceName = "SdjRοumko_Master"
    private val executor = Executors.newSingleThreadExecutor()
    private var player: AudioTrack? = null
    private var playingMaster = true
    private val eqBands = MasterEngine.defaultBands().toMutableList()

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        binding.status.text = "Loading WAV..."
        executor.execute {
            try {
                val data = WavCodec.read(contentResolver, uri)
                runOnUiThread {
                    loaded = data; mastered = null
                    binding.masterButton.isEnabled = true
                    binding.previewButton.isEnabled = false
                    binding.exportButton.isEnabled = false
                    binding.analysis.text = Analyzer.report(data)
                    binding.status.text = "Loaded: ${data.sampleRate} Hz / ${data.channels} ch"
                }
            } catch (e: Exception) {
                runOnUiThread { binding.status.text = "Error"; Toast.makeText(this, e.message ?: "Invalid WAV", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private val exporter = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/wav")) { uri: Uri? ->
        val out = mastered ?: return@registerForActivityResult
        uri ?: return@registerForActivityResult
        binding.status.text = "Exporting WAV 24-bit..."
        executor.execute {
            try {
                contentResolver.openOutputStream(uri).use { stream ->
                    requireNotNull(stream) { "Cannot open output file" }
                    WavCodec.write24(stream, out)
                }
                runOnUiThread { binding.status.text = "Export complete — 24-bit WAV" }
            } catch (e: Exception) { runOnUiThread { binding.status.text = "Export error: ${e.message}" } }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        buildEqUi()
        setupTargets()

        binding.openButton.setOnClickListener { picker.launch(arrayOf("audio/wav", "audio/x-wav", "audio/*")) }
        binding.masterButton.setOnClickListener {
            val input = loaded ?: return@setOnClickListener
            val settings = collectSettings()
            binding.status.text = "Analyzing + mastering offline..."
            binding.masterButton.isEnabled = false
            executor.execute {
                try {
                    val result = MasterEngine.master(input, settings)
                    runOnUiThread {
                        mastered = result
                        binding.analysis.text = "ORIGINAL\n${Analyzer.report(input)}\n\nMASTER\n${Analyzer.report(result)}"
                        binding.status.text = "Master ready — 24-band EQ + dynamics + saturation + limiter"
                        binding.masterButton.isEnabled = true
                        binding.previewButton.isEnabled = true
                        binding.exportButton.isEnabled = true
                    }
                } catch (e: Exception) {
                    runOnUiThread { binding.masterButton.isEnabled = true; binding.status.text = "Mastering error: ${e.message}" }
                }
            }
        }
        binding.previewButton.setOnClickListener { togglePreview() }
        binding.stopButton.setOnClickListener { stopPreview() }
        binding.exportButton.setOnClickListener { exporter.launch("${sourceName}_${System.currentTimeMillis()}.wav") }
    }

    private fun buildEqUi() {
        binding.eqContainer.removeAllViews()
        eqBands.forEachIndexed { index, band ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 6, 0, 10) }
            val label = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER_VERTICAL }
            val gain = SeekBar(this).apply { max = 240; progress = 120 }
            val q = SeekBar(this).apply { max = 118; progress = 7 }
            fun refresh() {
                band.gainDb = (gain.progress - 120) / 10f
                band.q = 0.20f + q.progress / 10f
                label.text = "B${index + 1}  ${formatFreq(band.frequency)}    Gain ${"%+.1f".format(Locale.US, band.gainDb)} dB    Q ${"%.2f".format(Locale.US, band.q)}"
            }
            gain.setOnSeekBarChangeListener(simpleListener { refresh() })
            q.setOnSeekBarChangeListener(simpleListener { refresh() })
            refresh(); row.addView(label); row.addView(gain); row.addView(q); binding.eqContainer.addView(row)
        }
    }

    private fun setupTargets() {
        binding.targetSeek.setOnSeekBarChangeListener(simpleListener {
            val v = -20f + binding.targetSeek.progress * 0.12f
            binding.targetLabel.text = "Target loudness: ${"%.1f".format(Locale.US, v)} LUFS"
        })
        binding.ceilingSeek.setOnSeekBarChangeListener(simpleListener {
            val v = -0.5f - binding.ceilingSeek.progress * 0.025f
            binding.ceilingLabel.text = "True-peak ceiling: ${"%.2f".format(Locale.US, v)} dBTP"
        })
        binding.intensitySeek.setOnSeekBarChangeListener(simpleListener { binding.intensityLabel.text = "Master intensity: ${binding.intensitySeek.progress}%" })
        binding.widthSeek.setOnSeekBarChangeListener(simpleListener { binding.widthLabel.text = "Stereo width: ${binding.widthSeek.progress}%" })
    }

    private fun collectSettings(): MasterSettings = MasterSettings(
        targetLufs = -20f + binding.targetSeek.progress * 0.12f,
        ceilingDb = -0.5f - binding.ceilingSeek.progress * 0.025f,
        intensity = binding.intensitySeek.progress / 100f,
        stereoWidth = binding.widthSeek.progress / 100f,
        eqBands = eqBands.map { it.copy() }
    )

    private fun togglePreview() {
        val original = loaded ?: return
        val master = mastered ?: return
        stopPreview()
        val data = if (playingMaster) master else original
        playingMaster = !playingMaster
        binding.previewButton.text = if (playingMaster) "PREVIEW MASTER / A-B" else "PREVIEW ORIGINAL / A-B"
        executor.execute { play(data) }
    }

    private fun play(data: WavData) {
        try {
            val channelMask = if (data.channels == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
            val min = AudioTrack.getMinBufferSize(data.sampleRate, channelMask, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(data.sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(channelMask).build())
                .setBufferSizeInBytes(maxOf(min, data.channels * 2 * 8192)).setTransferMode(AudioTrack.MODE_STREAM).build()
            player = track
            val pcm = ShortArray(data.samples.size) { (data.samples[it].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
            runOnUiThread { binding.stopButton.isEnabled = true; binding.status.text = "Playing ${if (data === mastered) "MASTER" else "ORIGINAL"} — A/B" }
            track.play(); var p = 0
            while (p < pcm.size && player === track) { p += track.write(pcm, p, minOf(4096, pcm.size - p)) }
            track.stop(); track.release()
            if (player === track) player = null
        } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Preview error: ${e.message}", Toast.LENGTH_SHORT).show() } }
    }

    private fun stopPreview() {
        player?.let { try { it.stop() } catch (_: Exception) {}; try { it.release() } catch (_: Exception) {} }
        player = null
        binding.stopButton.isEnabled = false
    }

    private fun simpleListener(action: () -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { action() }
        override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
        override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
    }

    private fun formatFreq(f: Float): String = if (f >= 1000f) "${"%.2f".format(Locale.US, f / 1000f)} kHz" else "${f.toInt()} Hz"

    override fun onDestroy() { stopPreview(); executor.shutdownNow(); super.onDestroy() }
}
