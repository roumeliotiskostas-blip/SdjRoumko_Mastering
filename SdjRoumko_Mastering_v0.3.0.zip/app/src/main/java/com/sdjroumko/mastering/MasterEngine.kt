package com.sdjroumko.mastering

import kotlin.math.*

data class MasterSettings(
    val targetLufs: Float = -14f,
    val ceilingDb: Float = -1.0f,
    val intensity: Float = 0.70f,
    val stereoWidth: Float = 1.0f,
    val bassMonoHz: Float = 120f,
    val saturation: Float = 0.08f,
    val dynamics: Float = 0.55f,
    val eqBands: List<EqBand> = MasterEngine.defaultBands()
)

object MasterEngine {
    fun defaultBands(): List<EqBand> = listOf(
        25f, 32f, 40f, 50f, 63f, 80f, 100f, 125f, 160f, 200f, 250f, 315f,
        400f, 500f, 630f, 800f, 1000f, 1250f, 1600f, 2000f, 3150f, 5000f, 10000f, 16000f
    ).map { EqBand(it) }

    fun master(input: WavData, settings: MasterSettings = MasterSettings()): WavData {
        require(input.channels in 1..2) { "Only mono/stereo WAV is supported in this version." }
        val x = input.samples.copyOf()
        if (x.isEmpty()) return input

        removeDc(x, input.channels)
        val eq = ParametricEq(input.sampleRate, settings.eqBands)
        eq.process(x, input.channels)

        // Gentle program-dependent multiband dynamics. Four crossover regions are
        // deliberately conservative to preserve transients and stereo image.
        multibandCompress(x, input, settings)
        applyStereoControl(x, input.channels, settings.stereoWidth, settings.bassMonoHz, input.sampleRate)

        // Musical saturation before peak control.
        val drive = (settings.saturation * settings.intensity).coerceIn(0f, 0.35f)
        if (drive > 0f) {
            val norm = tanh(1f + drive)
            for (i in x.indices) x[i] = tanh(x[i] * (1f + drive * 4f)) / norm
        }

        // Loudness matching. Limit the amount of automatic gain so the engine does
        // not destroy dynamics just to chase a number.
        val measured = Analyzer.lufsApprox(WavData(input.sampleRate, input.channels, x))
        val gainDb = ((settings.targetLufs - measured) * settings.intensity).coerceIn(-3f, 6f)
        val gain = 10f.pow(gainDb / 20f)
        for (i in x.indices) x[i] *= gain

        oversampledLimiter(x, input.channels, input.sampleRate, settings.ceilingDb, settings.intensity)
        dither24(x)
        return WavData(input.sampleRate, input.channels, x)
    }

    private fun removeDc(x: FloatArray, channels: Int) {
        val prevIn = FloatArray(channels)
        val prevOut = FloatArray(channels)
        val hp = 0.995f
        var i = 0
        while (i < x.size) {
            for (ch in 0 until channels) {
                val k = i + ch; if (k >= x.size) break
                val y = hp * (prevOut[ch] + x[k] - prevIn[ch])
                prevIn[ch] = x[k]; prevOut[ch] = y; x[k] = y
            }
            i += channels
        }
    }

    private fun multibandCompress(x: FloatArray, d: WavData, s: MasterSettings) {
        if (x.isEmpty()) return
        val bands = arrayOf(
            BandCompressor(90f, 0.65f, 2.0f, 0.018f, 0.140f),
            BandCompressor(500f, 0.72f, 1.7f, 0.012f, 0.120f),
            BandCompressor(4000f, 0.78f, 1.55f, 0.008f, 0.100f),
            BandCompressor(Float.POSITIVE_INFINITY, 0.82f, 1.4f, 0.006f, 0.080f)
        )
        val low = OnePoleLP(d.sampleRate.toFloat(), 90f)
        val midLow = OnePoleLP(d.sampleRate.toFloat(), 500f)
        val midHigh = OnePoleLP(d.sampleRate.toFloat(), 4000f)
        var i = 0
        while (i < x.size) {
            for (ch in 0 until d.channels) {
                val k = i + ch; if (k >= x.size) continue
                val v = x[k]
                val a = low.process(ch, v)
                val bAll = midLow.process(ch, v)
                val b = bAll - a
                val cAll = midHigh.process(ch, v)
                val c = cAll - bAll
                val e = v - cAll
                x[k] = bands[0].process(a, ch, s.dynamics * s.intensity) +
                        bands[1].process(b, ch, s.dynamics * s.intensity) +
                        bands[2].process(c, ch, s.dynamics * s.intensity) +
                        bands[3].process(e, ch, s.dynamics * s.intensity)
            }
            i += d.channels
        }
    }

    private fun applyStereoControl(x: FloatArray, channels: Int, width: Float, bassMonoHz: Float, sampleRate: Int) {
        if (channels != 2) return
        val w = width.coerceIn(0f, 1.35f)
        val bass = OnePoleLP(sampleRate.toFloat(), bassMonoHz)
        var i = 0
        while (i + 1 < x.size) {
            val l = x[i]; val r = x[i + 1]
            val mid = (l + r) * 0.5f
            val side = (l - r) * 0.5f * w
            val bassMid = bass.process(0, mid)
            val bassSide = 0f
            val highMid = mid - bassMid
            x[i] = bassMid + highMid + side
            x[i + 1] = bassMid + highMid - side
            i += 2
        }
    }

    private fun oversampledLimiter(x: FloatArray, channels: Int, sampleRate: Int, ceilingDb: Float, intensity: Float) {
        val ceiling = 10f.pow(ceilingDb / 20f).coerceIn(0.5f, 0.999f)
        val look = max(1, (sampleRate * 0.0025f).toInt())
        val gain = FloatArray(x.size) { 1f }
        var i = x.size - 1
        while (i >= 0) {
            var p = 0f
            val end = min(x.size - 1, i + look * channels)
            var k = i
            while (k <= end) { p = max(p, abs(x[k])); k += channels }
            var g = if (p > ceiling) ceiling / p else 1f
            g = g.pow(0.55f + intensity * 0.35f)
            gain[i] = g
            i--
        }
        for (j in x.indices) x[j] *= gain[j]
        // 4x interpolated true-peak safety pass.
        for (j in 0 until x.size - channels) {
            val a = x[j]; val b = x[j + channels]
            val p = max(max(abs(a), abs(b)), max(abs((3f*a+b)*0.25f), abs((a+3f*b)*0.25f)))
            if (p > ceiling) {
                val g = ceiling / p
                x[j] *= g; x[j + channels] *= g
            }
        }
        for (j in x.indices) x[j] = x[j].coerceIn(-ceiling, ceiling)
    }

    private fun dither24(x: FloatArray) {
        val lsb = 1f / 8388608f
        var seed = 0x13579BDF
        for (i in x.indices) {
            seed = seed * 1664525 + 1013904223
            val a = ((seed ushr 8) and 0xFFFF) / 65535f - 0.5f
            seed = seed * 1664525 + 1013904223
            val b = ((seed ushr 8) and 0xFFFF) / 65535f - 0.5f
            x[i] += (a + b) * lsb
        }
    }

    private class OnePoleLP(private val sr: Float, private val cutoff: Float) {
        private val z = FloatArray(2)
        private val a = exp((-2.0 * Math.PI * cutoff / sr)).toFloat()
        fun process(ch: Int, input: Float): Float {
            val y = (1f - a) * input + a * z[ch.coerceIn(0, 1)]
            z[ch.coerceIn(0, 1)] = y
            return y
        }
    }

    private class BandCompressor(private val marker: Float, private val threshold: Float, private val ratio: Float, attackSec: Float, releaseSec: Float) {
        private val env = FloatArray(2)
        private val attack = exp(-1f / (attackSec * 48000f))
        private val release = exp(-1f / (releaseSec * 48000f))
        fun process(v: Float, ch: Int, amount: Float): Float {
            val c = ch.coerceIn(0, 1)
            val a = abs(v)
            env[c] = if (a > env[c]) attack * env[c] + (1f - attack) * a else release * env[c] + (1f - release) * a
            if (env[c] <= threshold) return v
            val compressed = threshold + (env[c] - threshold) / (1f + (ratio - 1f) * amount.coerceIn(0f, 1f))
            return v * (compressed / env[c]).coerceIn(0.45f, 1f)
        }
    }
}
