package com.sdjroumko.mastering

import kotlin.math.*

enum class FilterType { BELL, LOW_SHELF, HIGH_SHELF, HIGH_PASS, LOW_PASS, NOTCH }

data class EqBand(
    var frequency: Float,
    var gainDb: Float = 0f,
    var q: Float = 0.707f,
    var type: FilterType = FilterType.BELL,
    var enabled: Boolean = true
)

private class Biquad(private val sampleRate: Float, private val band: EqBand) {
    private var b0 = 1f; private var b1 = 0f; private var b2 = 0f
    private var a1 = 0f; private var a2 = 0f
    private var z1 = 0f; private var z2 = 0f

    init { update() }

    fun update() {
        val f = band.frequency.coerceIn(10f, sampleRate * 0.45f)
        val q = band.q.coerceIn(0.05f, 20f)
        val a = 10.0.pow((band.gainDb / 40.0)).toFloat()
        val w = 2f * Math.PI.toFloat() * f / sampleRate
        val cw = cos(w); val sw = sin(w)
        val alpha = sw / (2f * q)
        val beta = 2f * sqrt(a) * alpha
        var bb0: Float; var bb1: Float; var bb2: Float; var aa0: Float; var aa1: Float; var aa2: Float
        when (band.type) {
            FilterType.BELL -> {
                bb0 = 1f + alpha * a; bb1 = -2f * cw; bb2 = 1f - alpha * a
                aa0 = 1f + alpha / a; aa1 = -2f * cw; aa2 = 1f - alpha / a
            }
            FilterType.LOW_SHELF -> {
                bb0 = a * ((a + 1f) - (a - 1f) * cw + beta)
                bb1 = 2f * a * ((a - 1f) - (a + 1f) * cw)
                bb2 = a * ((a + 1f) - (a - 1f) * cw - beta)
                aa0 = (a + 1f) + (a - 1f) * cw + beta
                aa1 = -2f * ((a - 1f) + (a + 1f) * cw)
                aa2 = (a + 1f) + (a - 1f) * cw - beta
            }
            FilterType.HIGH_SHELF -> {
                bb0 = a * ((a + 1f) + (a - 1f) * cw + beta)
                bb1 = -2f * a * ((a - 1f) + (a + 1f) * cw)
                bb2 = a * ((a + 1f) + (a - 1f) * cw - beta)
                aa0 = (a + 1f) - (a - 1f) * cw + beta
                aa1 = 2f * ((a - 1f) - (a + 1f) * cw)
                aa2 = (a + 1f) - (a - 1f) * cw - beta
            }
            FilterType.HIGH_PASS -> {
                bb0 = (1f + cw) / 2f; bb1 = -(1f + cw); bb2 = (1f + cw) / 2f
                aa0 = 1f + alpha; aa1 = -2f * cw; aa2 = 1f - alpha
            }
            FilterType.LOW_PASS -> {
                bb0 = (1f - cw) / 2f; bb1 = 1f - cw; bb2 = (1f - cw) / 2f
                aa0 = 1f + alpha; aa1 = -2f * cw; aa2 = 1f - alpha
            }
            FilterType.NOTCH -> {
                bb0 = 1f; bb1 = -2f * cw; bb2 = 1f
                aa0 = 1f + alpha; aa1 = -2f * cw; aa2 = 1f - alpha
            }
        }
        b0 = bb0 / aa0; b1 = bb1 / aa0; b2 = bb2 / aa0
        a1 = aa1 / aa0; a2 = aa2 / aa0
    }

    fun process(x: Float): Float {
        val y = b0 * x + z1
        z1 = b1 * x - a1 * y + z2
        z2 = b2 * x - a2 * y
        return y
    }
}

class ParametricEq(sampleRate: Int, bands: List<EqBand>) {
    private val left = bands.filter { it.enabled }.map { Biquad(sampleRate.toFloat(), it) }
    private val right = bands.filter { it.enabled }.map { Biquad(sampleRate.toFloat(), it) }

    fun process(samples: FloatArray, channels: Int) {
        if (left.isEmpty()) return
        if (channels == 1) {
            for (i in samples.indices) {
                var y = samples[i]
                for (f in left) y = f.process(y)
                samples[i] = y
            }
        } else {
            var i = 0
            while (i + 1 < samples.size) {
                var l = samples[i]; var r = samples[i + 1]
                for (f in left) l = f.process(l)
                for (f in right) r = f.process(r)
                samples[i] = l; samples[i + 1] = r
                i += 2
            }
        }
    }
}
